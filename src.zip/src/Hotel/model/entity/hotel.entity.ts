import { Entity, PrimaryGeneratedColumn, Column, OneToMany, CreateDateColumn, UpdateDateColumn, DeleteDateColumn } from 'typeorm';
import { Expose } from 'class-transformer';
import { Room } from './room.entity';
import { ApiProperty } from '@nestjs/swagger';

@Entity()
export class Hotel {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'varchar', length: 255 })
  @ApiProperty({ description: 'The name of the hotel' })
  name: string;

  // اضافه کردن فیلد location برای نگهداری مختصات جغرافیایی
  @Column({ type: 'json', nullable: false })
  @ApiProperty({
    description: 'The geographical location of the hotel (latitude and longitude)',
    example: { latitude: 40.7128, longitude: 74.0060 }
  })
  location: { latitude: number; longitude: number };  // مختصات جغرافیایی هتل

  @CreateDateColumn({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
  @Expose()
  createdAt: Date;

  @UpdateDateColumn({
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP',
    onUpdate: 'CURRENT_TIMESTAMP',
  })
  @Expose()
  updatedAt: Date;

  @DeleteDateColumn()
  @Expose()
  deletedAt: Date;

  @OneToMany(() => Room, (room) => room.hotel)
  @ApiProperty({ type: () => Room, description: 'Rooms in the hotel' })
  rooms: Room[];
}