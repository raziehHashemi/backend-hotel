import { IsString, IsOptional, IsNotEmpty, IsNumber } from 'class-validator';

export class UpdateRoomDto {
  @IsString()
  @IsOptional() 
  name?: string;  

  @IsString()
  @IsOptional()  
  description?: string;  

  @IsNumber()
  @IsOptional()  
  price?: number; 

  
  @IsString()
  @IsOptional()  
  location?: string;  
}