import { IsString, IsOptional, IsObject, IsNotEmpty } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class UpdateHotelDto {
  @IsString()
  @IsOptional()  
  @ApiProperty({ description: 'The name of the hotel', required: false })
  name?: string;  

  @IsObject()
  @IsOptional() 
  @ApiProperty({
    description: 'The geographical location of the hotel',
    required: false,
    example: { latitude: 40.7128, longitude: 74.0060 }
  })
  location?: { latitude: number; longitude: number };  

  @IsString()
  @IsOptional()  
  @ApiProperty({ description: 'The address of the hotel', required: false })
  address?: string;  
}