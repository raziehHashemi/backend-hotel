import { IsString, IsObject, IsNotEmpty } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class CreateHotelDto {
  @IsString()
  @IsNotEmpty()
  @ApiProperty({ description: 'The name of the hotel' })
  name: string;

  @IsObject()
  @IsNotEmpty()
  @ApiProperty({
    description: 'The geographical location of the hotel',
    example: { latitude: 40.7128, longitude: 74.0060 },
  })
  location: { latitude: number; longitude: number };
}