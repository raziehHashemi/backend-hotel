import { IsString, IsNotEmpty, IsDateString, IsOptional } from 'class-validator';

export class CreateReservationDto {
  @IsString()
  @IsNotEmpty()
  hotelId: string;  // شناسه هتل

  @IsString()
  @IsNotEmpty()
  roomId: string;  // شناسه اتاق

  @IsString()
  @IsNotEmpty()
  userId: string;  // شناسه کاربر

  @IsDateString()
  @IsNotEmpty()
  checkInDate: Date;  // تاریخ ورود

  @IsDateString()
  @IsNotEmpty()
  checkOutDate: Date;  // تاریخ خروج

  @IsDateString()
  @IsOptional()  // این فیلد اختیاری است
  expirationDate?: Date;  // تاریخ انقضا (اختیاری)
}