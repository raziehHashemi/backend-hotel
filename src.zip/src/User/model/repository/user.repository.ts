import { Injectable } from '@nestjs/common';
import { EntityRepository, Repository } from 'typeorm';
import { User } from '../../model/entity/user.entity';  
import { CreateUserDto } from '../../dto/create-user.dto';  

@Injectable()  
@EntityRepository(User)
export class UserRepository extends Repository<User> {

  
  async createUser(createUserDto: CreateUserDto): Promise<User | null> {
    const user = this.create(createUserDto);  
    return await this.save(user);  
  }

  
  async getUserById(id: string): Promise<User | null> {
    return await this.findOne({ where: { id } }) || null;
  }

  
  async updateUser(id: string, updatedData: CreateUserDto): Promise<User | null> {
    const user = await this.findOne({ where: { id } });  

    if (!user) {
      return null;  
    }

    
    this.merge(user, updatedData);  
    return await this.save(user);  
  }

  
  async deleteUser(id: string): Promise<void> {
    await this.softDelete(id); 
  }
}